"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, Phone, Edit, Trash2, Star, MapPin, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface EmergencyContact {
  id: number
  name: string
  relationship: string
  phone: string
  email?: string
  address?: string
  notes?: string
  isPrimary: boolean
  category: string
}

export default function EmergencyContactsPage() {
  const [contacts, setContacts] = useState<EmergencyContact[]>([
    {
      id: 1,
      name: "Dr. Sarah Johnson",
      relationship: "Primary Care Doctor",
      phone: "(555) 123-4567",
      email: "dr.johnson@healthcenter.com",
      address: "123 Medical Plaza, Suite 200",
      notes: "Available Mon-Fri 9AM-5PM",
      isPrimary: true,
      category: "medical",
    },
    {
      id: 2,
      name: "John Smith",
      relationship: "Son",
      phone: "(555) 987-6543",
      email: "john.smith@email.com",
      address: "456 Oak Street, Anytown",
      notes: "Lives nearby, available 24/7",
      isPrimary: true,
      category: "family",
    },
    {
      id: 3,
      name: "City General Hospital",
      relationship: "Emergency Room",
      phone: "(555) 911-1234",
      address: "789 Hospital Drive",
      notes: "24/7 Emergency Services",
      isPrimary: false,
      category: "medical",
    },
  ])

  const [newContact, setNewContact] = useState<Partial<EmergencyContact>>({
    name: "",
    relationship: "",
    phone: "",
    email: "",
    address: "",
    notes: "",
    isPrimary: false,
    category: "family",
  })

  const [editingContact, setEditingContact] = useState<EmergencyContact | null>(null)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)

  // Load contacts from localStorage on component mount
  useEffect(() => {
    const savedContacts = localStorage.getItem("emergencyContacts")
    if (savedContacts) {
      setContacts(JSON.parse(savedContacts))
    }
  }, [])

  // Save contacts to localStorage whenever contacts change
  useEffect(() => {
    localStorage.setItem("emergencyContacts", JSON.stringify(contacts))
  }, [contacts])

  const categories = [
    { id: "family", name: "Family", icon: "👨‍👩‍👧‍👦", color: "bg-blue-100 text-blue-800" },
    { id: "medical", name: "Medical", icon: "🏥", color: "bg-red-100 text-red-800" },
    { id: "friends", name: "Friends", icon: "👥", color: "bg-green-100 text-green-800" },
    { id: "work", name: "Work", icon: "💼", color: "bg-purple-100 text-purple-800" },
    { id: "services", name: "Services", icon: "🔧", color: "bg-yellow-100 text-yellow-800" },
  ]

  const addContact = () => {
    if (newContact.name && newContact.phone) {
      const contact: EmergencyContact = {
        id: Date.now(),
        name: newContact.name,
        relationship: newContact.relationship || "",
        phone: newContact.phone,
        email: newContact.email || "",
        address: newContact.address || "",
        notes: newContact.notes || "",
        isPrimary: newContact.isPrimary || false,
        category: newContact.category || "family",
      }
      setContacts([...contacts, contact])
      setNewContact({
        name: "",
        relationship: "",
        phone: "",
        email: "",
        address: "",
        notes: "",
        isPrimary: false,
        category: "family",
      })
      setIsAddDialogOpen(false)
    }
  }

  const updateContact = () => {
    if (editingContact) {
      setContacts(contacts.map((contact) => (contact.id === editingContact.id ? editingContact : contact)))
      setEditingContact(null)
      setIsEditDialogOpen(false)
    }
  }

  const deleteContact = (id: number) => {
    setContacts(contacts.filter((contact) => contact.id !== id))
  }

  const togglePrimary = (id: number) => {
    setContacts(
      contacts.map((contact) => (contact.id === id ? { ...contact, isPrimary: !contact.isPrimary } : contact)),
    )
  }

  const callContact = (phone: string) => {
    window.location.href = `tel:${phone}`
  }

  const getCategoryInfo = (categoryId: string) => {
    return categories.find((cat) => cat.id === categoryId) || categories[0]
  }

  const primaryContacts = contacts.filter((contact) => contact.isPrimary)
  const contactsByCategory = categories.map((category) => ({
    ...category,
    contacts: contacts.filter((contact) => contact.category === category.id),
  }))

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Emergency Contacts</h1>
              <p className="text-gray-600">Quick access to important contacts</p>
            </div>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Add Contact
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-xl">Add Emergency Contact</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="contact-name" className="text-base">
                    Name *
                  </Label>
                  <Input
                    id="contact-name"
                    placeholder="Full name"
                    value={newContact.name || ""}
                    onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="contact-relationship" className="text-base">
                    Relationship
                  </Label>
                  <Input
                    id="contact-relationship"
                    placeholder="e.g., Doctor, Son, Friend"
                    value={newContact.relationship || ""}
                    onChange={(e) => setNewContact({ ...newContact, relationship: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="contact-phone" className="text-base">
                    Phone Number *
                  </Label>
                  <Input
                    id="contact-phone"
                    type="tel"
                    placeholder="(555) 123-4567"
                    value={newContact.phone || ""}
                    onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="contact-email" className="text-base">
                    Email
                  </Label>
                  <Input
                    id="contact-email"
                    type="email"
                    placeholder="email@example.com"
                    value={newContact.email || ""}
                    onChange={(e) => setNewContact({ ...newContact, email: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="contact-category" className="text-base">
                    Category
                  </Label>
                  <Select
                    value={newContact.category}
                    onValueChange={(value) => setNewContact({ ...newContact, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {categories.map((category) => (
                        <SelectItem key={category.id} value={category.id}>
                          {category.icon} {category.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="contact-notes" className="text-base">
                    Notes
                  </Label>
                  <Textarea
                    id="contact-notes"
                    placeholder="Additional information..."
                    value={newContact.notes || ""}
                    onChange={(e) => setNewContact({ ...newContact, notes: e.target.value })}
                    className="text-base"
                    rows={2}
                  />
                </div>
                <Button onClick={addContact} className="w-full text-base" size="lg">
                  Add Contact
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Emergency Services */}
        <Card className="border-2 border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-xl text-red-900 flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5" />
              <span>Emergency Services</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button
                onClick={() => callContact("911")}
                className="h-20 bg-red-600 hover:bg-red-700 text-white flex-col space-y-2"
                size="lg"
              >
                <Phone className="w-8 h-8" />
                <div className="text-center">
                  <div className="text-2xl font-bold">911</div>
                  <div className="text-sm">Emergency</div>
                </div>
              </Button>
              <Button
                onClick={() => callContact("1-800-222-1222")}
                className="h-20 bg-orange-600 hover:bg-orange-700 text-white flex-col space-y-2"
                size="lg"
              >
                <AlertTriangle className="w-8 h-8" />
                <div className="text-center">
                  <div className="text-lg font-bold">Poison Control</div>
                  <div className="text-xs">1-800-222-1222</div>
                </div>
              </Button>
              <Button
                onClick={() => callContact("988")}
                className="h-20 bg-pink-600 hover:bg-pink-700 text-white flex-col space-y-2"
                size="lg"
              >
                <Phone className="w-8 h-8" />
                <div className="text-center">
                  <div className="text-lg font-bold">Crisis Line</div>
                  <div className="text-sm">988</div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Primary Contacts */}
        {primaryContacts.length > 0 && (
          <Card className="border-2 border-yellow-200 bg-yellow-50">
            <CardHeader>
              <CardTitle className="text-xl text-yellow-900 flex items-center space-x-2">
                <Star className="w-5 h-5" />
                <span>Primary Contacts</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {primaryContacts.map((contact) => (
                  <div key={contact.id} className="bg-white p-4 rounded-lg border border-yellow-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{contact.name}</h3>
                        <p className="text-sm text-gray-600">{contact.relationship}</p>
                      </div>
                      <Badge className={getCategoryInfo(contact.category).color}>
                        {getCategoryInfo(contact.category).icon}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <Button
                        onClick={() => callContact(contact.phone)}
                        className="w-full bg-green-600 hover:bg-green-700 text-white"
                        size="lg"
                      >
                        <Phone className="w-5 h-5 mr-2" />
                        Call {contact.phone}
                      </Button>
                      {contact.notes && <p className="text-xs text-gray-600 bg-gray-50 p-2 rounded">{contact.notes}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Contacts by Category */}
        {contactsByCategory.map(
          (category) =>
            category.contacts.length > 0 && (
              <Card key={category.id} className="border-2">
                <CardHeader>
                  <CardTitle className="text-xl flex items-center space-x-2">
                    <span className="text-2xl">{category.icon}</span>
                    <span>{category.name}</span>
                    <Badge variant="outline">{category.contacts.length}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {category.contacts.map((contact) => (
                      <div key={contact.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="font-semibold">{contact.name}</h3>
                            {contact.isPrimary && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                          </div>
                          <p className="text-sm text-gray-600 mb-1">{contact.relationship}</p>
                          <div className="flex items-center space-x-4 text-xs text-gray-500">
                            <span className="flex items-center">
                              <Phone className="w-3 h-3 mr-1" />
                              {contact.phone}
                            </span>
                            {contact.address && (
                              <span className="flex items-center">
                                <MapPin className="w-3 h-3 mr-1" />
                                {contact.address.split(",")[0]}
                              </span>
                            )}
                          </div>
                          {contact.notes && (
                            <p className="text-xs text-gray-600 mt-2 bg-white p-2 rounded border">{contact.notes}</p>
                          )}
                        </div>
                        <div className="flex items-center space-x-2">
                          <Button
                            onClick={() => callContact(contact.phone)}
                            size="sm"
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <Phone className="w-4 h-4" />
                          </Button>
                          <Button
                            onClick={() => togglePrimary(contact.id)}
                            variant="outline"
                            size="sm"
                            className={contact.isPrimary ? "bg-yellow-100 border-yellow-300" : ""}
                          >
                            <Star className={`w-4 h-4 ${contact.isPrimary ? "text-yellow-500 fill-current" : ""}`} />
                          </Button>
                          <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
                            <DialogTrigger asChild>
                              <Button onClick={() => setEditingContact(contact)} variant="outline" size="sm">
                                <Edit className="w-4 h-4" />
                              </Button>
                            </DialogTrigger>
                            <DialogContent className="sm:max-w-md">
                              <DialogHeader>
                                <DialogTitle className="text-xl">Edit Contact</DialogTitle>
                              </DialogHeader>
                              {editingContact && (
                                <div className="space-y-4">
                                  <div>
                                    <Label htmlFor="edit-name" className="text-base">
                                      Name
                                    </Label>
                                    <Input
                                      id="edit-name"
                                      value={editingContact.name}
                                      onChange={(e) => setEditingContact({ ...editingContact, name: e.target.value })}
                                      className="text-base"
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="edit-phone" className="text-base">
                                      Phone
                                    </Label>
                                    <Input
                                      id="edit-phone"
                                      value={editingContact.phone}
                                      onChange={(e) => setEditingContact({ ...editingContact, phone: e.target.value })}
                                      className="text-base"
                                    />
                                  </div>
                                  <div>
                                    <Label htmlFor="edit-notes" className="text-base">
                                      Notes
                                    </Label>
                                    <Textarea
                                      id="edit-notes"
                                      value={editingContact.notes || ""}
                                      onChange={(e) => setEditingContact({ ...editingContact, notes: e.target.value })}
                                      className="text-base"
                                      rows={2}
                                    />
                                  </div>
                                  <div className="flex space-x-2">
                                    <Button onClick={updateContact} className="flex-1">
                                      Update
                                    </Button>
                                    <Button
                                      onClick={() => deleteContact(editingContact.id)}
                                      variant="destructive"
                                      size="sm"
                                    >
                                      <Trash2 className="w-4 h-4" />
                                    </Button>
                                  </div>
                                </div>
                              )}
                            </DialogContent>
                          </Dialog>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ),
        )}

        {contacts.length === 0 && (
          <Card className="border-2 border-dashed">
            <CardContent className="p-12 text-center">
              <Phone className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No contacts added</h3>
              <p className="text-gray-500 mb-6">Add emergency contacts for quick access during urgent situations</p>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="lg">
                    <Plus className="w-5 h-5 mr-2" />
                    Add Your First Contact
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-xl">Add Emergency Contact</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="contact-name" className="text-base">
                        Name *
                      </Label>
                      <Input
                        id="contact-name"
                        placeholder="Full name"
                        value={newContact.name || ""}
                        onChange={(e) => setNewContact({ ...newContact, name: e.target.value })}
                        className="text-base"
                      />
                    </div>
                    <div>
                      <Label htmlFor="contact-phone" className="text-base">
                        Phone Number *
                      </Label>
                      <Input
                        id="contact-phone"
                        type="tel"
                        placeholder="(555) 123-4567"
                        value={newContact.phone || ""}
                        onChange={(e) => setNewContact({ ...newContact, phone: e.target.value })}
                        className="text-base"
                      />
                    </div>
                    <Button onClick={addContact} className="w-full text-base" size="lg">
                      Add Contact
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}

        {/* Tips */}
        <Card className="border-2 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-xl text-blue-900">💡 Emergency Contact Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-blue-800">
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Keep at least 3 emergency contacts with different phone numbers</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Include both local and out-of-area contacts</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Mark your most important contacts as "Primary" for quick access</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Update contact information regularly</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Include medical professionals, family members, and close friends</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
