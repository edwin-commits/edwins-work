"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Heart,
  Calendar,
  Pill,
  TrendingUp,
  BookOpen,
  Settings,
  Plus,
  CheckCircle,
  AlertCircle,
  Clock,
  Phone,
  Shield,
} from "lucide-react"
import Link from "next/link"

export default function Dashboard() {
  const [currentTime, setCurrentTime] = useState(new Date())
  const [todayHabits] = useState([
    { id: 1, name: "Drink Water", completed: 6, target: 8, icon: "💧" },
    { id: 2, name: "Take Medication", completed: 2, target: 2, icon: "💊" },
    { id: 3, name: "Exercise", completed: 0, target: 1, icon: "🏃" },
    { id: 4, name: "Sleep 8 Hours", completed: 1, target: 1, icon: "😴" },
  ])

  const [upcomingReminders] = useState([
    { id: 1, type: "medication", title: "Blood Pressure Medication", time: "2:00 PM", urgent: false },
    { id: 2, type: "appointment", title: "Doctor Appointment", time: "Tomorrow 10:00 AM", urgent: true },
    { id: 3, type: "medication", title: "Vitamin D", time: "6:00 PM", urgent: false },
  ])

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  const completedHabits = todayHabits.filter((habit) => habit.completed >= habit.target).length
  const totalHabits = todayHabits.length
  const overallProgress = (completedHabits / totalHabits) * 100

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Good Morning! 👋</h1>
            <p className="text-lg text-gray-600 mt-1">
              {currentTime.toLocaleDateString("en-US", {
                weekday: "long",
                year: "numeric",
                month: "long",
                day: "numeric",
              })}
            </p>
          </div>
          <Link href="/settings">
            <Button variant="outline" size="lg" className="text-base bg-transparent">
              <Settings className="w-5 h-5 mr-2" />
              Settings
            </Button>
          </Link>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Today's Progress</p>
                  <p className="text-2xl font-bold text-green-600">
                    {completedHabits}/{totalHabits}
                  </p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
              <Progress value={overallProgress} className="mt-3" />
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Next Reminder</p>
                  <p className="text-lg font-semibold text-blue-600">2:00 PM</p>
                </div>
                <Clock className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Health Score</p>
                  <p className="text-2xl font-bold text-purple-600">85%</p>
                </div>
                <Heart className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Streak</p>
                  <p className="text-2xl font-bold text-orange-600">7 days</p>
                </div>
                <CheckCircle className="w-8 h-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Today's Habits */}
          <Card className="lg:col-span-2 border-2">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-xl">Today's Health Habits</CardTitle>
              <Link href="/habits">
                <Button size="sm">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Habit
                </Button>
              </Link>
            </CardHeader>
            <CardContent className="space-y-4">
              {todayHabits.map((habit) => (
                <div key={habit.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{habit.icon}</span>
                    <div>
                      <p className="font-medium text-lg">{habit.name}</p>
                      <p className="text-sm text-gray-600">
                        {habit.completed} of {habit.target} completed
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center space-x-3">
                    <Progress value={(habit.completed / habit.target) * 100} className="w-20" />
                    {habit.completed >= habit.target ? (
                      <CheckCircle className="w-6 h-6 text-green-600" />
                    ) : (
                      <Button size="sm" variant="outline">
                        Mark Done
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Upcoming Reminders */}
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-xl">Upcoming Reminders</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {upcomingReminders.map((reminder) => (
                <div key={reminder.id} className="flex items-start space-x-3 p-3 bg-gray-50 rounded-lg">
                  <div className="flex-shrink-0">
                    {reminder.type === "medication" ? (
                      <Pill className="w-5 h-5 text-blue-600 mt-1" />
                    ) : (
                      <Calendar className="w-5 h-5 text-green-600 mt-1" />
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm">{reminder.title}</p>
                    <p className="text-xs text-gray-600">{reminder.time}</p>
                    {reminder.urgent && (
                      <Badge variant="destructive" className="mt-1 text-xs">
                        <AlertCircle className="w-3 h-3 mr-1" />
                        Urgent
                      </Badge>
                    )}
                  </div>
                </div>
              ))}
              <Link href="/reminders">
                <Button variant="outline" className="w-full mt-3 bg-transparent">
                  View All Reminders
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl">Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              <Link href="/symptoms">
                <Button variant="outline" size="lg" className="h-20 flex-col space-y-2 w-full bg-transparent">
                  <Heart className="w-6 h-6" />
                  <span className="text-sm">Track Symptoms</span>
                </Button>
              </Link>
              <Link href="/medications">
                <Button variant="outline" size="lg" className="h-20 flex-col space-y-2 w-full bg-transparent">
                  <Pill className="w-6 h-6" />
                  <span className="text-sm">Medications</span>
                </Button>
              </Link>
              <Link href="/appointments">
                <Button variant="outline" size="lg" className="h-20 flex-col space-y-2 w-full bg-transparent">
                  <Calendar className="w-6 h-6" />
                  <span className="text-sm">Appointments</span>
                </Button>
              </Link>
              <Link href="/first-aid">
                <Button
                  variant="outline"
                  size="lg"
                  className="h-20 flex-col space-y-2 w-full bg-red-50 border-red-200 hover:bg-red-100"
                >
                  <Shield className="w-6 h-6 text-red-600" />
                  <span className="text-sm text-red-600">First Aid</span>
                </Button>
              </Link>
              <Link href="/emergency-contacts">
                <Button
                  variant="outline"
                  size="lg"
                  className="h-20 flex-col space-y-2 w-full bg-orange-50 border-orange-200 hover:bg-orange-100"
                >
                  <Phone className="w-6 h-6 text-orange-600" />
                  <span className="text-sm text-orange-600">Emergency</span>
                </Button>
              </Link>
              <Link href="/education">
                <Button variant="outline" size="lg" className="h-20 flex-col space-y-2 w-full bg-transparent">
                  <BookOpen className="w-6 h-6" />
                  <span className="text-sm">Health Tips</span>
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
