"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, Heart, Calendar, Clock, TrendingUp } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SymptomsPage() {
  const [symptoms, setSymptoms] = useState([
    {
      id: 1,
      type: "Headache",
      severity: "Moderate",
      date: "2024-01-18",
      time: "10:30 AM",
      notes: "Started after working on computer for 3 hours",
      icon: "🤕",
    },
    {
      id: 2,
      type: "Fatigue",
      severity: "Mild",
      date: "2024-01-17",
      time: "2:00 PM",
      notes: "Feeling tired after lunch",
      icon: "😴",
    },
    {
      id: 3,
      type: "Stomach Pain",
      severity: "Severe",
      date: "2024-01-16",
      time: "8:00 PM",
      notes: "Sharp pain after dinner",
      icon: "🤢",
    },
  ])

  const [symptomInsights, setSymptomInsights] = useState({
    mostCommon: "Headache",
    averageSeverity: "Moderate",
    weeklyTrend: "Stable",
    lastLogged: "2 hours ago",
  })

  const [showInsights, setShowInsights] = useState(true)

  const [newSymptom, setNewSymptom] = useState({
    type: "",
    severity: "Mild",
    notes: "",
    customType: "",
  })

  const commonSymptoms = [
    { name: "Headache", icon: "🤕" },
    { name: "Fatigue", icon: "😴" },
    { name: "Nausea", icon: "🤢" },
    { name: "Dizziness", icon: "😵" },
    { name: "Chest Pain", icon: "💔" },
    { name: "Shortness of Breath", icon: "😮‍💨" },
    { name: "Fever", icon: "🤒" },
    { name: "Cough", icon: "😷" },
    { name: "Joint Pain", icon: "🦴" },
    { name: "Back Pain", icon: "🫸" },
  ]

  const addSymptom = () => {
    const symptomType = newSymptom.type === "custom" ? newSymptom.customType : newSymptom.type
    if (symptomType.trim()) {
      const symptomIcon = commonSymptoms.find((s) => s.name === symptomType)?.icon || "⚠️"
      const now = new Date()
      setSymptoms([
        {
          id: Date.now(),
          type: symptomType,
          severity: newSymptom.severity,
          date: now.toISOString().split("T")[0],
          time: now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }),
          notes: newSymptom.notes,
          icon: symptomIcon,
        },
        ...symptoms,
      ])
      setNewSymptom({ type: "", severity: "Mild", notes: "", customType: "" })
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "Mild":
        return "bg-green-100 text-green-800"
      case "Moderate":
        return "bg-yellow-100 text-yellow-800"
      case "Severe":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Symptom Tracker</h1>
              <p className="text-gray-600">Monitor your health symptoms</p>
            </div>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Log Symptom
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-xl">Log New Symptom</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="symptom-type" className="text-base">
                    Symptom Type
                  </Label>
                  <Select
                    value={newSymptom.type}
                    onValueChange={(value) => setNewSymptom({ ...newSymptom, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select a symptom" />
                    </SelectTrigger>
                    <SelectContent>
                      {commonSymptoms.map((symptom) => (
                        <SelectItem key={symptom.name} value={symptom.name}>
                          {symptom.icon} {symptom.name}
                        </SelectItem>
                      ))}
                      <SelectItem value="custom">✏️ Custom Symptom</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {newSymptom.type === "custom" && (
                  <div>
                    <Label htmlFor="custom-symptom" className="text-base">
                      Custom Symptom
                    </Label>
                    <Input
                      id="custom-symptom"
                      placeholder="Describe your symptom"
                      value={newSymptom.customType}
                      onChange={(e) => setNewSymptom({ ...newSymptom, customType: e.target.value })}
                      className="text-base"
                    />
                  </div>
                )}

                <div>
                  <Label htmlFor="severity" className="text-base">
                    Severity
                  </Label>
                  <Select
                    value={newSymptom.severity}
                    onValueChange={(value) => setNewSymptom({ ...newSymptom, severity: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Mild">🟢 Mild</SelectItem>
                      <SelectItem value="Moderate">🟡 Moderate</SelectItem>
                      <SelectItem value="Severe">🔴 Severe</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="notes" className="text-base">
                    Notes (Optional)
                  </Label>
                  <Textarea
                    id="notes"
                    placeholder="Any additional details about the symptom..."
                    value={newSymptom.notes}
                    onChange={(e) => setNewSymptom({ ...newSymptom, notes: e.target.value })}
                    className="text-base"
                    rows={3}
                  />
                </div>

                <Button onClick={addSymptom} className="w-full text-base" size="lg">
                  Log Symptom
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Quick Symptom Buttons */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl">Quick Log</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {commonSymptoms.slice(0, 10).map((symptom) => (
                <Button
                  key={symptom.name}
                  variant="outline"
                  className="h-16 flex-col space-y-1 text-sm bg-transparent"
                  onClick={() => {
                    const now = new Date()
                    setSymptoms([
                      {
                        id: Date.now(),
                        type: symptom.name,
                        severity: "Mild",
                        date: now.toISOString().split("T")[0],
                        time: now.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" }),
                        notes: "",
                        icon: symptom.icon,
                      },
                      ...symptoms,
                    ])
                  }}
                >
                  <span className="text-lg">{symptom.icon}</span>
                  <span>{symptom.name}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Symptom Insights */}
        {showInsights && symptoms.length > 0 && (
          <Card className="border-2 bg-purple-50">
            <CardHeader>
              <CardTitle className="text-xl text-purple-900 flex items-center justify-between">
                <span className="flex items-center space-x-2">
                  <TrendingUp className="w-5 h-5" />
                  <span>Health Insights</span>
                </span>
                <Button variant="ghost" size="sm" onClick={() => setShowInsights(false)} className="text-purple-600">
                  ×
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-white rounded-lg border border-purple-200">
                  <div className="text-2xl mb-2">📊</div>
                  <p className="text-sm text-purple-600 font-medium">Most Common</p>
                  <p className="text-lg font-bold text-purple-900">{symptomInsights.mostCommon}</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg border border-purple-200">
                  <div className="text-2xl mb-2">📈</div>
                  <p className="text-sm text-purple-600 font-medium">Average Severity</p>
                  <p className="text-lg font-bold text-purple-900">{symptomInsights.averageSeverity}</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg border border-purple-200">
                  <div className="text-2xl mb-2">📅</div>
                  <p className="text-sm text-purple-600 font-medium">Weekly Trend</p>
                  <p className="text-lg font-bold text-purple-900">{symptomInsights.weeklyTrend}</p>
                </div>
                <div className="text-center p-4 bg-white rounded-lg border border-purple-200">
                  <div className="text-2xl mb-2">⏰</div>
                  <p className="text-sm text-purple-600 font-medium">Last Logged</p>
                  <p className="text-lg font-bold text-purple-900">{symptomInsights.lastLogged}</p>
                </div>
              </div>
              <div className="mt-4 p-4 bg-white rounded-lg border border-purple-200">
                <h3 className="font-medium text-purple-900 mb-2">📋 Recommendations</h3>
                <div className="space-y-2 text-sm text-purple-800">
                  <p className="flex items-start space-x-2">
                    <span className="text-purple-600 mt-1">•</span>
                    <span>Consider tracking triggers like stress, sleep, or diet</span>
                  </p>
                  <p className="flex items-start space-x-2">
                    <span className="text-purple-600 mt-1">•</span>
                    <span>Share this data with your healthcare provider</span>
                  </p>
                  <p className="flex items-start space-x-2">
                    <span className="text-purple-600 mt-1">•</span>
                    <span>Look for patterns in timing and severity</span>
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Symptoms History */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl">Recent Symptoms</CardTitle>
          </CardHeader>
          <CardContent>
            {symptoms.length === 0 ? (
              <div className="text-center py-12">
                <Heart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No symptoms logged</h3>
                <p className="text-gray-500">Start tracking your symptoms to monitor your health</p>
              </div>
            ) : (
              <div className="space-y-4">
                {symptoms.map((symptom) => (
                  <div key={symptom.id} className="flex items-start space-x-4 p-4 bg-gray-50 rounded-lg">
                    <span className="text-2xl flex-shrink-0">{symptom.icon}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="text-lg font-semibold">{symptom.type}</h3>
                        <Badge className={getSeverityColor(symptom.severity)}>{symptom.severity}</Badge>
                      </div>
                      <div className="flex items-center space-x-4 text-sm text-gray-600 mb-2">
                        <span className="flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {new Date(symptom.date).toLocaleDateString()}
                        </span>
                        <span className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {symptom.time}
                        </span>
                      </div>
                      {symptom.notes && (
                        <p className="text-gray-700 text-sm bg-white p-2 rounded border">{symptom.notes}</p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Health Tips */}
        <Card className="border-2 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-xl text-blue-900">💡 Health Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-blue-800">
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Log symptoms as soon as you notice them for accurate tracking</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Include details about what you were doing when symptoms started</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Share your symptom history with your healthcare provider</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Seek immediate medical attention for severe symptoms</span>
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Symptom Patterns */}
        {symptoms.length >= 3 && (
          <Card className="border-2 bg-green-50">
            <CardHeader>
              <CardTitle className="text-xl text-green-900">🔍 Pattern Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="p-4 bg-white rounded-lg border border-green-200">
                    <h3 className="font-medium text-green-900 mb-2">Time Patterns</h3>
                    <p className="text-sm text-green-800">Most symptoms occur in the afternoon (60%)</p>
                    <div className="mt-2 bg-green-100 rounded-full h-2">
                      <div className="bg-green-600 h-2 rounded-full" style={{ width: "60%" }}></div>
                    </div>
                  </div>
                  <div className="p-4 bg-white rounded-lg border border-green-200">
                    <h3 className="font-medium text-green-900 mb-2">Severity Distribution</h3>
                    <div className="space-y-1 text-sm text-green-800">
                      <div className="flex justify-between">
                        <span>Mild: 40%</span>
                        <span>Moderate: 50%</span>
                        <span>Severe: 10%</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="p-4 bg-white rounded-lg border border-green-200">
                  <h3 className="font-medium text-green-900 mb-2">💡 Insights</h3>
                  <p className="text-sm text-green-800">
                    Based on your symptom history, consider discussing stress management techniques with your healthcare
                    provider, as symptoms seem to peak during afternoon hours.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
