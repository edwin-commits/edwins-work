"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { ArrowLeft, Plus, Pill, Clock, Bell, CheckCircle, AlertTriangle } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function MedicationsPage() {
  const [medications, setMedications] = useState([
    {
      id: 1,
      name: "Blood Pressure Medication",
      dosage: "10mg",
      frequency: "Twice daily",
      times: ["8:00 AM", "8:00 PM"],
      nextDose: "8:00 PM",
      taken: true,
      reminders: true,
      color: "blue",
    },
    {
      id: 2,
      name: "Vitamin D",
      dosage: "1000 IU",
      frequency: "Once daily",
      times: ["9:00 AM"],
      nextDose: "Tomorrow 9:00 AM",
      taken: true,
      reminders: true,
      color: "yellow",
    },
    {
      id: 3,
      name: "Pain Relief",
      dosage: "200mg",
      frequency: "As needed",
      times: [],
      nextDose: "As needed",
      taken: false,
      reminders: false,
      color: "red",
    },
  ])

  const [newMedication, setNewMedication] = useState({
    name: "",
    dosage: "",
    frequency: "once",
    times: [""],
    reminders: true,
    color: "blue",
  })

  const addMedication = () => {
    if (newMedication.name.trim() && newMedication.dosage.trim()) {
      const frequencyMap = {
        once: "Once daily",
        twice: "Twice daily",
        three: "Three times daily",
        asneeded: "As needed",
      }

      setMedications([
        ...medications,
        {
          id: Date.now(),
          name: newMedication.name,
          dosage: newMedication.dosage,
          frequency: frequencyMap[newMedication.frequency as keyof typeof frequencyMap],
          times: newMedication.times.filter((time) => time.trim()),
          nextDose: newMedication.times[0] || "As needed",
          taken: false,
          reminders: newMedication.reminders,
          color: newMedication.color,
        },
      ])
      setNewMedication({
        name: "",
        dosage: "",
        frequency: "once",
        times: [""],
        reminders: true,
        color: "blue",
      })
    }
  }

  const toggleTaken = (id: number) => {
    setMedications(medications.map((med) => (med.id === id ? { ...med, taken: !med.taken } : med)))
  }

  const toggleReminders = (id: number) => {
    setMedications(medications.map((med) => (med.id === id ? { ...med, reminders: !med.reminders } : med)))
  }

  const getColorClass = (color: string) => {
    const colors = {
      blue: "bg-blue-100 border-blue-300",
      yellow: "bg-yellow-100 border-yellow-300",
      red: "bg-red-100 border-red-300",
      green: "bg-green-100 border-green-300",
      purple: "bg-purple-100 border-purple-300",
    }
    return colors[color as keyof typeof colors] || colors.blue
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Medications</h1>
              <p className="text-gray-600">Manage your medication schedule</p>
            </div>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Add Medication
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-xl">Add New Medication</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="med-name" className="text-base">
                    Medication Name
                  </Label>
                  <Input
                    id="med-name"
                    placeholder="e.g., Aspirin"
                    value={newMedication.name}
                    onChange={(e) => setNewMedication({ ...newMedication, name: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="med-dosage" className="text-base">
                    Dosage
                  </Label>
                  <Input
                    id="med-dosage"
                    placeholder="e.g., 100mg"
                    value={newMedication.dosage}
                    onChange={(e) => setNewMedication({ ...newMedication, dosage: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="med-frequency" className="text-base">
                    Frequency
                  </Label>
                  <Select
                    value={newMedication.frequency}
                    onValueChange={(value) => setNewMedication({ ...newMedication, frequency: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="once">Once daily</SelectItem>
                      <SelectItem value="twice">Twice daily</SelectItem>
                      <SelectItem value="three">Three times daily</SelectItem>
                      <SelectItem value="asneeded">As needed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="med-time" className="text-base">
                    Time
                  </Label>
                  <Input
                    id="med-time"
                    type="time"
                    value={newMedication.times[0]}
                    onChange={(e) => setNewMedication({ ...newMedication, times: [e.target.value] })}
                    className="text-base"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <Label htmlFor="med-reminders" className="text-base">
                    Enable Reminders
                  </Label>
                  <Switch
                    id="med-reminders"
                    checked={newMedication.reminders}
                    onCheckedChange={(checked) => setNewMedication({ ...newMedication, reminders: checked })}
                  />
                </div>
                <Button onClick={addMedication} className="w-full text-base" size="lg">
                  Add Medication
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Today's Schedule */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Clock className="w-5 h-5" />
              <span>Today's Schedule</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {medications
                .filter((med) => med.times.length > 0)
                .map((med) => (
                  <div key={med.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full ${getColorClass(med.color).split(" ")[0]}`} />
                      <div>
                        <p className="font-medium">{med.name}</p>
                        <p className="text-sm text-gray-600">
                          {med.dosage} - {med.nextDose}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {med.taken ? (
                        <Badge variant="default" className="bg-green-100 text-green-800">
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Taken
                        </Badge>
                      ) : (
                        <Badge variant="outline">Pending</Badge>
                      )}
                      <Button onClick={() => toggleTaken(med.id)} variant={med.taken ? "outline" : "default"} size="sm">
                        {med.taken ? "Undo" : "Mark Taken"}
                      </Button>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        {/* All Medications */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl">All Medications</CardTitle>
          </CardHeader>
          <CardContent>
            {medications.length === 0 ? (
              <div className="text-center py-12">
                <Pill className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No medications added</h3>
                <p className="text-gray-500">Add your medications to track and get reminders</p>
              </div>
            ) : (
              <div className="space-y-4">
                {medications.map((med) => (
                  <Card key={med.id} className={`border-2 ${getColorClass(med.color)}`}>
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <Pill className="w-5 h-5 text-gray-600" />
                            <h3 className="text-lg font-semibold">{med.name}</h3>
                          </div>
                          <div className="space-y-1 text-sm text-gray-600">
                            <p>
                              <strong>Dosage:</strong> {med.dosage}
                            </p>
                            <p>
                              <strong>Frequency:</strong> {med.frequency}
                            </p>
                            {med.times.length > 0 && (
                              <p>
                                <strong>Times:</strong> {med.times.join(", ")}
                              </p>
                            )}
                            <p>
                              <strong>Next Dose:</strong> {med.nextDose}
                            </p>
                          </div>
                        </div>
                        <div className="flex flex-col items-end space-y-2">
                          <div className="flex items-center space-x-2">
                            <Bell className={`w-4 h-4 ${med.reminders ? "text-blue-600" : "text-gray-400"}`} />
                            <Switch checked={med.reminders} onCheckedChange={() => toggleReminders(med.id)} size="sm" />
                          </div>
                          {med.frequency !== "As needed" && (
                            <Badge variant={med.taken ? "default" : "secondary"}>
                              {med.taken ? "Taken Today" : "Not Taken"}
                            </Badge>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Important Reminders */}
        <Card className="border-2 bg-amber-50 border-amber-200">
          <CardHeader>
            <CardTitle className="text-xl text-amber-900 flex items-center space-x-2">
              <AlertTriangle className="w-5 h-5" />
              <span>Important Reminders</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-amber-800">
              <p className="flex items-start space-x-2">
                <span className="text-amber-600 mt-1">•</span>
                <span>Always take medications as prescribed by your healthcare provider</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-amber-600 mt-1">•</span>
                <span>Don't skip doses or stop taking medications without consulting your doctor</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-amber-600 mt-1">•</span>
                <span>Keep track of side effects and report them to your healthcare provider</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-amber-600 mt-1">•</span>
                <span>Store medications in a cool, dry place away from children</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
