"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Search, Heart, AlertTriangle, Phone, CheckCircle } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"

export default function FirstAidPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", name: "All", icon: "🏥", color: "bg-gray-100" },
    { id: "emergency", name: "Emergency", icon: "🚨", color: "bg-red-100" },
    { id: "wounds", name: "Wounds", icon: "🩹", color: "bg-blue-100" },
    { id: "breathing", name: "Breathing", icon: "🫁", color: "bg-green-100" },
    { id: "burns", name: "Burns", icon: "🔥", color: "bg-orange-100" },
    { id: "poisoning", name: "Poisoning", icon: "☠️", color: "bg-purple-100" },
    { id: "fractures", name: "Fractures", icon: "🦴", color: "bg-yellow-100" },
  ]

  const firstAidGuides = [
    {
      id: 1,
      title: "CPR (Cardiopulmonary Resuscitation)",
      category: "emergency",
      urgency: "critical",
      icon: "❤️",
      summary: "Life-saving technique for cardiac arrest",
      steps: [
        "Check for responsiveness - tap shoulders and shout 'Are you okay?'",
        "Call 911 immediately or have someone else do it",
        "Place person on firm, flat surface on their back",
        "Tilt head back slightly and lift chin",
        "Place heel of one hand on center of chest between nipples",
        "Place other hand on top, interlacing fingers",
        "Push hard and fast at least 2 inches deep",
        "Allow complete chest recoil between compressions",
        "Compress at rate of 100-120 per minute",
        "Continue until emergency services arrive",
      ],
      warnings: [
        "Only perform if person is unresponsive and not breathing normally",
        "Do not stop CPR until professional help arrives",
        "If trained, give 2 rescue breaths after every 30 compressions",
      ],
      whenToCall911: "Immediately - this is a life-threatening emergency",
    },
    {
      id: 2,
      title: "Choking (Heimlich Maneuver)",
      category: "emergency",
      urgency: "critical",
      icon: "🫁",
      summary: "Remove airway obstruction in conscious person",
      steps: [
        "Ask 'Are you choking?' - if they can't speak, cough, or breathe, act immediately",
        "Stand behind the person",
        "Place arms around their waist",
        "Make a fist with one hand",
        "Place fist above navel, below ribcage",
        "Grasp fist with other hand",
        "Give quick, upward thrusts",
        "Continue until object is expelled or person becomes unconscious",
        "If unconscious, begin CPR",
      ],
      warnings: [
        "Do not perform on pregnant women or infants under 1 year",
        "For infants, use back blows and chest thrusts instead",
        "Seek medical attention even if successful",
      ],
      whenToCall911: "Call immediately if person becomes unconscious",
    },
    {
      id: 3,
      title: "Severe Bleeding Control",
      category: "wounds",
      urgency: "high",
      icon: "🩸",
      summary: "Stop life-threatening bleeding",
      steps: [
        "Ensure your safety - wear gloves if available",
        "Have person lie down if possible",
        "Remove any visible debris (do not remove embedded objects)",
        "Apply direct pressure with clean cloth or bandage",
        "Press firmly and continuously",
        "If blood soaks through, add more layers without removing first",
        "Elevate injured area above heart level if possible",
        "Apply pressure to pressure points if bleeding continues",
        "Secure bandage with tape or cloth strips",
        "Monitor for signs of shock",
      ],
      warnings: [
        "Do not remove embedded objects",
        "Do not use tourniquet unless trained",
        "Watch for signs of shock (pale, cold, rapid pulse)",
      ],
      whenToCall911: "Call for severe bleeding that won't stop",
    },
    {
      id: 4,
      title: "Burns Treatment",
      category: "burns",
      urgency: "medium",
      icon: "🔥",
      summary: "Treat thermal, chemical, and electrical burns",
      steps: [
        "Remove person from heat source safely",
        "Remove hot or burned clothing (if not stuck to skin)",
        "Cool burn with cool (not cold) running water for 10-20 minutes",
        "Remove jewelry before swelling occurs",
        "Cover burn with sterile, non-adhesive bandage",
        "Take over-the-counter pain medication if needed",
        "Keep burned area elevated if possible",
        "Do not break blisters",
        "Monitor for signs of infection",
      ],
      warnings: [
        "Do not use ice, butter, or home remedies",
        "Do not break blisters",
        "Seek immediate care for burns on face, hands, feet, or genitals",
        "Call 911 for large burns or electrical burns",
      ],
      whenToCall911: "Large burns, electrical burns, or burns on face/hands/feet",
    },
    {
      id: 5,
      title: "Allergic Reaction (Anaphylaxis)",
      category: "emergency",
      urgency: "critical",
      icon: "🤧",
      summary: "Treat severe allergic reactions",
      steps: [
        "Recognize symptoms: difficulty breathing, swelling, hives, rapid pulse",
        "Call 911 immediately",
        "Help person use epinephrine auto-injector if available",
        "Have person lie down with legs elevated",
        "Loosen tight clothing",
        "Cover with blanket to prevent shock",
        "Do not give anything by mouth",
        "Be prepared to perform CPR if needed",
        "Stay with person until help arrives",
      ],
      warnings: [
        "This is a life-threatening emergency",
        "Symptoms can worsen rapidly",
        "Even if symptoms improve, seek medical attention",
      ],
      whenToCall911: "Immediately for any signs of severe allergic reaction",
    },
    {
      id: 6,
      title: "Fracture (Broken Bone)",
      category: "fractures",
      urgency: "medium",
      icon: "🦴",
      summary: "Stabilize suspected broken bones",
      steps: [
        "Do not move person unless in immediate danger",
        "Check for circulation below injury",
        "Immobilize the injured area",
        "Support joints above and below fracture",
        "Use splint materials: boards, magazines, pillows",
        "Secure splint with bandages or cloth",
        "Apply ice pack wrapped in cloth",
        "Elevate if possible to reduce swelling",
        "Monitor circulation regularly",
        "Give pain medication if conscious and not allergic",
      ],
      warnings: [
        "Do not try to realign bone",
        "Do not move person with suspected spine injury",
        "Watch for signs of shock",
      ],
      whenToCall911: "Open fractures, spine injuries, or multiple fractures",
    },
    {
      id: 7,
      title: "Poisoning",
      category: "poisoning",
      urgency: "high",
      icon: "☠️",
      summary: "Respond to suspected poisoning",
      steps: [
        "Identify the poison if possible",
        "Call Poison Control: 1-800-222-1222",
        "Follow Poison Control instructions exactly",
        "If person is conscious, give small sips of water if instructed",
        "Save poison container and any vomit for medical personnel",
        "Monitor breathing and consciousness",
        "Be prepared to perform CPR if needed",
        "Do not induce vomiting unless instructed",
      ],
      warnings: [
        "Do not induce vomiting unless told to do so",
        "Do not give activated charcoal unless instructed",
        "Different poisons require different treatments",
      ],
      whenToCall911: "If person is unconscious, having seizures, or trouble breathing",
    },
    {
      id: 8,
      title: "Stroke Recognition (FAST)",
      category: "emergency",
      urgency: "critical",
      icon: "🧠",
      summary: "Recognize and respond to stroke symptoms",
      steps: [
        "F - Face: Ask person to smile. Does face droop on one side?",
        "A - Arms: Ask person to raise both arms. Does one drift downward?",
        "S - Speech: Ask person to repeat simple phrase. Is speech slurred?",
        "T - Time: If any signs present, call 911 immediately",
        "Note time symptoms first appeared",
        "Keep person calm and comfortable",
        "Do not give food, water, or medication",
        "Monitor breathing and consciousness",
        "Be prepared to perform CPR if needed",
      ],
      warnings: [
        "Time is critical - every minute counts",
        "Do not drive person to hospital yourself",
        "Do not give aspirin or other medications",
      ],
      whenToCall911: "Immediately if any FAST signs are present",
    },
  ]

  const filteredGuides = firstAidGuides.filter((guide) => {
    const matchesSearch =
      guide.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      guide.summary.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "all" || guide.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case "critical":
        return "bg-red-100 text-red-800 border-red-300"
      case "high":
        return "bg-orange-100 text-orange-800 border-orange-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 border-yellow-300"
      default:
        return "bg-gray-100 text-gray-800 border-gray-300"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-50 to-orange-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">First Aid Guide</h1>
              <p className="text-gray-600">Emergency procedures available offline</p>
            </div>
          </div>
          <div className="flex items-center space-x-2 bg-red-100 px-4 py-2 rounded-lg border border-red-200">
            <AlertTriangle className="w-5 h-5 text-red-600" />
            <span className="text-red-800 font-medium">Emergency: Call 911</span>
          </div>
        </div>

        {/* Emergency Numbers */}
        <Card className="border-2 border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="text-xl text-red-900 flex items-center space-x-2">
              <Phone className="w-5 h-5" />
              <span>Emergency Numbers</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center p-4 bg-white rounded-lg border border-red-200">
                <Phone className="w-8 h-8 text-red-600 mx-auto mb-2" />
                <p className="text-2xl font-bold text-red-600">911</p>
                <p className="text-sm text-red-800">Emergency Services</p>
              </div>
              <div className="text-center p-4 bg-white rounded-lg border border-red-200">
                <AlertTriangle className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                <p className="text-lg font-bold text-orange-600">1-800-222-1222</p>
                <p className="text-sm text-orange-800">Poison Control</p>
              </div>
              <div className="text-center p-4 bg-white rounded-lg border border-red-200">
                <Heart className="w-8 h-8 text-pink-600 mx-auto mb-2" />
                <p className="text-lg font-bold text-pink-600">988</p>
                <p className="text-sm text-pink-800">Suicide & Crisis Lifeline</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Search and Categories */}
        <Card className="border-2">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 mb-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search first aid procedures..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 text-base"
                  />
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              {categories.map((category) => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  className={`h-16 flex-col space-y-1 text-sm ${
                    selectedCategory === category.id ? "" : category.color
                  }`}
                  onClick={() => setSelectedCategory(category.id)}
                >
                  <span className="text-lg">{category.icon}</span>
                  <span>{category.name}</span>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* First Aid Guides */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredGuides.map((guide) => (
            <Dialog key={guide.id}>
              <DialogTrigger asChild>
                <Card className="border-2 hover:shadow-lg transition-shadow cursor-pointer">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between mb-2">
                      <Badge className={getUrgencyColor(guide.urgency)}>{guide.urgency.toUpperCase()}</Badge>
                      <span className="text-2xl">{guide.icon}</span>
                    </div>
                    <CardTitle className="text-lg leading-tight">{guide.title}</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-4">{guide.summary}</p>
                    <div className="flex items-center justify-between">
                      <Badge variant="outline" className="text-xs">
                        {categories.find((c) => c.id === guide.category)?.name}
                      </Badge>
                      <Button size="sm" variant="outline">
                        View Steps
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </DialogTrigger>
              <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
                <DialogHeader>
                  <DialogTitle className="flex items-center space-x-3 text-xl">
                    <span className="text-2xl">{guide.icon}</span>
                    <span>{guide.title}</span>
                    <Badge className={getUrgencyColor(guide.urgency)}>{guide.urgency.toUpperCase()}</Badge>
                  </DialogTitle>
                </DialogHeader>
                <div className="space-y-6">
                  <p className="text-gray-700">{guide.summary}</p>

                  {/* When to Call 911 */}
                  <div className="bg-red-50 border border-red-200 rounded-lg p-4">
                    <h3 className="font-semibold text-red-900 mb-2 flex items-center">
                      <Phone className="w-4 h-4 mr-2" />
                      When to Call 911
                    </h3>
                    <p className="text-red-800 text-sm">{guide.whenToCall911}</p>
                  </div>

                  {/* Steps */}
                  <div>
                    <h3 className="font-semibold text-gray-900 mb-3 flex items-center">
                      <CheckCircle className="w-4 h-4 mr-2" />
                      Step-by-Step Instructions
                    </h3>
                    <ol className="space-y-2">
                      {guide.steps.map((step, index) => (
                        <li key={index} className="flex items-start space-x-3">
                          <span className="flex-shrink-0 w-6 h-6 bg-blue-100 text-blue-800 rounded-full flex items-center justify-center text-sm font-medium">
                            {index + 1}
                          </span>
                          <span className="text-sm text-gray-700">{step}</span>
                        </li>
                      ))}
                    </ol>
                  </div>

                  {/* Warnings */}
                  <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                    <h3 className="font-semibold text-yellow-900 mb-2 flex items-center">
                      <AlertTriangle className="w-4 h-4 mr-2" />
                      Important Warnings
                    </h3>
                    <ul className="space-y-1">
                      {guide.warnings.map((warning, index) => (
                        <li key={index} className="text-yellow-800 text-sm flex items-start">
                          <span className="text-yellow-600 mr-2">•</span>
                          {warning}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Emergency Action */}
                  <div className="bg-red-100 border border-red-300 rounded-lg p-4 text-center">
                    <Button size="lg" className="bg-red-600 hover:bg-red-700 text-white">
                      <Phone className="w-5 h-5 mr-2" />
                      Call 911 Now
                    </Button>
                  </div>
                </div>
              </DialogContent>
            </Dialog>
          ))}
        </div>

        {/* Offline Notice */}
        <Card className="border-2 bg-green-50 border-green-200">
          <CardContent className="p-6 text-center">
            <div className="flex items-center justify-center space-x-2 mb-3">
              <CheckCircle className="w-6 h-6 text-green-600" />
              <h3 className="text-lg font-semibold text-green-900">Available Offline</h3>
            </div>
            <p className="text-green-800">
              All first aid guides are stored locally and accessible without internet connection. Perfect for
              emergencies when connectivity might be limited.
            </p>
          </CardContent>
        </Card>

        {/* Disclaimer */}
        <Card className="border-2 bg-gray-50">
          <CardContent className="p-6">
            <h3 className="font-semibold text-gray-900 mb-2">⚠️ Medical Disclaimer</h3>
            <p className="text-sm text-gray-700">
              This information is for educational purposes only and should not replace professional medical advice.
              Always call emergency services for serious injuries or medical emergencies. Consider taking a certified
              first aid course for hands-on training.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
