"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, CheckCircle, Circle, Target, TrendingUp } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function HabitsPage() {
  const [habits, setHabits] = useState([
    {
      id: 1,
      name: "Drink Water",
      icon: "💧",
      target: 8,
      completed: 6,
      streak: 5,
      category: "nutrition",
    },
    {
      id: 2,
      name: "Take Medication",
      icon: "💊",
      target: 2,
      completed: 2,
      streak: 12,
      category: "medication",
    },
    {
      id: 3,
      name: "Exercise",
      icon: "🏃",
      target: 1,
      completed: 0,
      streak: 3,
      category: "fitness",
    },
    {
      id: 4,
      name: "Sleep 8 Hours",
      icon: "😴",
      target: 1,
      completed: 1,
      streak: 7,
      category: "sleep",
    },
    {
      id: 5,
      name: "Meditation",
      icon: "🧘",
      target: 1,
      completed: 0,
      streak: 2,
      category: "mental",
    },
  ])

  const [newHabit, setNewHabit] = useState({
    name: "",
    icon: "⭐",
    target: 1,
    category: "general",
  })

  const addHabit = () => {
    if (newHabit.name.trim()) {
      setHabits([
        ...habits,
        {
          id: Date.now(),
          ...newHabit,
          completed: 0,
          streak: 0,
        },
      ])
      setNewHabit({ name: "", icon: "⭐", target: 1, category: "general" })
    }
  }

  const toggleHabit = (id: number) => {
    setHabits(
      habits.map((habit) =>
        habit.id === id ? { ...habit, completed: habit.completed < habit.target ? habit.completed + 1 : 0 } : habit,
      ),
    )
  }

  const totalCompleted = habits.filter((h) => h.completed >= h.target).length
  const totalHabits = habits.length
  const overallProgress = totalHabits > 0 ? (totalCompleted / totalHabits) * 100 : 0

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Health Habits</h1>
              <p className="text-gray-600">Build healthy routines that last</p>
            </div>
          </div>
          <Dialog>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Add Habit
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-xl">Create New Habit</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="habit-name" className="text-base">
                    Habit Name
                  </Label>
                  <Input
                    id="habit-name"
                    placeholder="e.g., Drink more water"
                    value={newHabit.name}
                    onChange={(e) => setNewHabit({ ...newHabit, name: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="habit-icon" className="text-base">
                    Icon
                  </Label>
                  <Select value={newHabit.icon} onValueChange={(value) => setNewHabit({ ...newHabit, icon: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="💧">💧 Water</SelectItem>
                      <SelectItem value="🏃">🏃 Exercise</SelectItem>
                      <SelectItem value="💊">💊 Medication</SelectItem>
                      <SelectItem value="😴">😴 Sleep</SelectItem>
                      <SelectItem value="🧘">🧘 Meditation</SelectItem>
                      <SelectItem value="📚">📚 Reading</SelectItem>
                      <SelectItem value="🥗">🥗 Healthy Eating</SelectItem>
                      <SelectItem value="⭐">⭐ General</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="habit-target" className="text-base">
                    Daily Target
                  </Label>
                  <Input
                    id="habit-target"
                    type="number"
                    min="1"
                    value={newHabit.target}
                    onChange={(e) => setNewHabit({ ...newHabit, target: Number.parseInt(e.target.value) || 1 })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="habit-category" className="text-base">
                    Category
                  </Label>
                  <Select
                    value={newHabit.category}
                    onValueChange={(value) => setNewHabit({ ...newHabit, category: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nutrition">Nutrition</SelectItem>
                      <SelectItem value="fitness">Fitness</SelectItem>
                      <SelectItem value="medication">Medication</SelectItem>
                      <SelectItem value="sleep">Sleep</SelectItem>
                      <SelectItem value="mental">Mental Health</SelectItem>
                      <SelectItem value="general">General</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={addHabit} className="w-full text-base" size="lg">
                  Create Habit
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Progress Overview */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5" />
              <span>Today's Progress</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-4">
              <span className="text-lg font-medium">
                {totalCompleted} of {totalHabits} habits completed
              </span>
              <Badge variant={overallProgress === 100 ? "default" : "secondary"} className="text-sm">
                {Math.round(overallProgress)}%
              </Badge>
            </div>
            <Progress value={overallProgress} className="h-3" />
          </CardContent>
        </Card>

        {/* Habits List */}
        <div className="space-y-4">
          {habits.map((habit) => (
            <Card key={habit.id} className="border-2 hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <span className="text-3xl">{habit.icon}</span>
                    <div>
                      <h3 className="text-xl font-semibold">{habit.name}</h3>
                      <div className="flex items-center space-x-4 mt-1">
                        <span className="text-sm text-gray-600">
                          {habit.completed} / {habit.target} completed
                        </span>
                        <Badge variant="outline" className="text-xs">
                          🔥 {habit.streak} day streak
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className="text-right">
                      <Progress value={(habit.completed / habit.target) * 100} className="w-24 mb-2" />
                      <p className="text-xs text-gray-500">{Math.round((habit.completed / habit.target) * 100)}%</p>
                    </div>
                    <Button
                      onClick={() => toggleHabit(habit.id)}
                      variant={habit.completed >= habit.target ? "default" : "outline"}
                      size="lg"
                      className="min-w-[120px]"
                    >
                      {habit.completed >= habit.target ? (
                        <>
                          <CheckCircle className="w-5 h-5 mr-2" />
                          Complete
                        </>
                      ) : (
                        <>
                          <Circle className="w-5 h-5 mr-2" />
                          Mark Done
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {habits.length === 0 && (
          <Card className="border-2 border-dashed">
            <CardContent className="p-12 text-center">
              <Target className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No habits yet</h3>
              <p className="text-gray-500 mb-6">Start building healthy routines by adding your first habit</p>
              <Dialog>
                <DialogTrigger asChild>
                  <Button size="lg">
                    <Plus className="w-5 h-5 mr-2" />
                    Add Your First Habit
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-xl">Create New Habit</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="habit-name" className="text-base">
                        Habit Name
                      </Label>
                      <Input
                        id="habit-name"
                        placeholder="e.g., Drink more water"
                        value={newHabit.name}
                        onChange={(e) => setNewHabit({ ...newHabit, name: e.target.value })}
                        className="text-base"
                      />
                    </div>
                    <div>
                      <Label htmlFor="habit-target" className="text-base">
                        Daily Target
                      </Label>
                      <Input
                        id="habit-target"
                        type="number"
                        min="1"
                        value={newHabit.target}
                        onChange={(e) => setNewHabit({ ...newHabit, target: Number.parseInt(e.target.value) || 1 })}
                        className="text-base"
                      />
                    </div>
                    <Button onClick={addHabit} className="w-full text-base" size="lg">
                      Create Habit
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
