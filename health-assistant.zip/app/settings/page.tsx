"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { ArrowLeft, Bell, Globe, Accessibility, Palette, Volume2, Moon, Sun, Smartphone } from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

export default function SettingsPage() {
  const [settings, setSettings] = useState({
    notifications: true,
    medicationReminders: true,
    appointmentReminders: true,
    habitReminders: true,
    language: "en",
    fontSize: [16],
    highContrast: false,
    darkMode: false,
    soundEnabled: true,
    volume: [70],
    vibration: true,
    largeButtons: false,
    screenReader: false,
  })

  const updateSetting = (key: string, value: any) => {
    setSettings((prev) => ({ ...prev, [key]: value }))
  }

  const languages = [
    { code: "en", name: "English", flag: "🇺🇸" },
    { code: "es", name: "Español", flag: "🇪🇸" },
    { code: "fr", name: "Français", flag: "🇫🇷" },
    { code: "de", name: "Deutsch", flag: "🇩🇪" },
    { code: "zh", name: "中文", flag: "🇨🇳" },
    { code: "ar", name: "العربية", flag: "🇸🇦" },
    { code: "hi", name: "हिन्दी", flag: "🇮🇳" },
    { code: "pt", name: "Português", flag: "🇧🇷" },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center space-x-4">
          <Link href="/">
            <Button variant="outline" size="icon">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
            <p className="text-gray-600">Customize your health assistant experience</p>
          </div>
        </div>

        {/* Notifications */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Bell className="w-5 h-5" />
              <span>Notifications</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="notifications" className="text-base font-medium">
                  Enable Notifications
                </Label>
                <p className="text-sm text-gray-600">Receive all app notifications</p>
              </div>
              <Switch
                id="notifications"
                checked={settings.notifications}
                onCheckedChange={(checked) => updateSetting("notifications", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="med-reminders" className="text-base font-medium">
                  Medication Reminders
                </Label>
                <p className="text-sm text-gray-600">Get reminded to take your medications</p>
              </div>
              <Switch
                id="med-reminders"
                checked={settings.medicationReminders}
                onCheckedChange={(checked) => updateSetting("medicationReminders", checked)}
                disabled={!settings.notifications}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="appointment-reminders" className="text-base font-medium">
                  Appointment Reminders
                </Label>
                <p className="text-sm text-gray-600">Get reminded about upcoming appointments</p>
              </div>
              <Switch
                id="appointment-reminders"
                checked={settings.appointmentReminders}
                onCheckedChange={(checked) => updateSetting("appointmentReminders", checked)}
                disabled={!settings.notifications}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="habit-reminders" className="text-base font-medium">
                  Habit Reminders
                </Label>
                <p className="text-sm text-gray-600">Get reminded about your daily habits</p>
              </div>
              <Switch
                id="habit-reminders"
                checked={settings.habitReminders}
                onCheckedChange={(checked) => updateSetting("habitReminders", checked)}
                disabled={!settings.notifications}
              />
            </div>
          </CardContent>
        </Card>

        {/* Language & Region */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Globe className="w-5 h-5" />
              <span>Language & Region</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label htmlFor="language" className="text-base font-medium">
                  Language
                </Label>
                <Select value={settings.language} onValueChange={(value) => updateSetting("language", value)}>
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {languages.map((lang) => (
                      <SelectItem key={lang.code} value={lang.code}>
                        <span className="flex items-center space-x-2">
                          <span>{lang.flag}</span>
                          <span>{lang.name}</span>
                        </span>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Accessibility */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Accessibility className="w-5 h-5" />
              <span>Accessibility</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div>
              <Label htmlFor="font-size" className="text-base font-medium">
                Font Size
              </Label>
              <div className="mt-4 space-y-2">
                <Slider
                  id="font-size"
                  min={12}
                  max={24}
                  step={2}
                  value={settings.fontSize}
                  onValueChange={(value) => updateSetting("fontSize", value)}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Small</span>
                  <span>Current: {settings.fontSize[0]}px</span>
                  <span>Large</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="high-contrast" className="text-base font-medium">
                  High Contrast Mode
                </Label>
                <p className="text-sm text-gray-600">Increase contrast for better visibility</p>
              </div>
              <Switch
                id="high-contrast"
                checked={settings.highContrast}
                onCheckedChange={(checked) => updateSetting("highContrast", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="large-buttons" className="text-base font-medium">
                  Large Buttons
                </Label>
                <p className="text-sm text-gray-600">Make buttons larger and easier to tap</p>
              </div>
              <Switch
                id="large-buttons"
                checked={settings.largeButtons}
                onCheckedChange={(checked) => updateSetting("largeButtons", checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="screen-reader" className="text-base font-medium">
                  Screen Reader Support
                </Label>
                <p className="text-sm text-gray-600">Optimize for screen reader compatibility</p>
              </div>
              <Switch
                id="screen-reader"
                checked={settings.screenReader}
                onCheckedChange={(checked) => updateSetting("screenReader", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Display */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Palette className="w-5 h-5" />
              <span>Display</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="dark-mode" className="text-base font-medium flex items-center space-x-2">
                  {settings.darkMode ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
                  <span>Dark Mode</span>
                </Label>
                <p className="text-sm text-gray-600">Use dark theme to reduce eye strain</p>
              </div>
              <Switch
                id="dark-mode"
                checked={settings.darkMode}
                onCheckedChange={(checked) => updateSetting("darkMode", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Sound & Vibration */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Volume2 className="w-5 h-5" />
              <span>Sound & Vibration</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="sound-enabled" className="text-base font-medium">
                  Sound Effects
                </Label>
                <p className="text-sm text-gray-600">Play sounds for notifications and interactions</p>
              </div>
              <Switch
                id="sound-enabled"
                checked={settings.soundEnabled}
                onCheckedChange={(checked) => updateSetting("soundEnabled", checked)}
              />
            </div>

            <div>
              <Label htmlFor="volume" className="text-base font-medium">
                Volume Level
              </Label>
              <div className="mt-4 space-y-2">
                <Slider
                  id="volume"
                  min={0}
                  max={100}
                  step={10}
                  value={settings.volume}
                  onValueChange={(value) => updateSetting("volume", value)}
                  className="w-full"
                  disabled={!settings.soundEnabled}
                />
                <div className="flex justify-between text-sm text-gray-600">
                  <span>Quiet</span>
                  <span>{settings.volume[0]}%</span>
                  <span>Loud</span>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div>
                <Label htmlFor="vibration" className="text-base font-medium">
                  Vibration
                </Label>
                <p className="text-sm text-gray-600">Vibrate for notifications and alerts</p>
              </div>
              <Switch
                id="vibration"
                checked={settings.vibration}
                onCheckedChange={(checked) => updateSetting("vibration", checked)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Device Integration */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center space-x-2">
              <Smartphone className="w-5 h-5" />
              <span>Device Integration</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                <h3 className="font-medium text-blue-900 mb-2">Wearable Devices</h3>
                <p className="text-sm text-blue-800 mb-3">
                  Connect fitness trackers and smartwatches to automatically sync health data
                </p>
                <Button variant="outline" size="sm">
                  Connect Device
                </Button>
              </div>

              <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                <h3 className="font-medium text-green-900 mb-2">Health Apps</h3>
                <p className="text-sm text-green-800 mb-3">
                  Sync with other health apps to get a complete picture of your wellness
                </p>
                <Button variant="outline" size="sm">
                  Manage Connections
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Settings */}
        <Card className="border-2 bg-gray-50">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-medium text-gray-900">Settings saved automatically</h3>
                <p className="text-sm text-gray-600">Your preferences are updated in real-time</p>
              </div>
              <Button>Export Settings</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
