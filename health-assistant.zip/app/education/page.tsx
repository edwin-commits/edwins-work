"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, BookOpen, Search, Heart, Brain, Utensils, Dumbbell, Shield, Clock, Star } from "lucide-react"
import Link from "next/link"

export default function EducationPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("all")

  const categories = [
    { id: "all", name: "All Topics", icon: BookOpen, color: "bg-gray-100" },
    { id: "heart", name: "Heart Health", icon: Heart, color: "bg-red-100" },
    { id: "mental", name: "Mental Health", icon: Brain, color: "bg-purple-100" },
    { id: "nutrition", name: "Nutrition", icon: Utensils, color: "bg-green-100" },
    { id: "fitness", name: "Fitness", icon: Dumbbell, color: "bg-blue-100" },
    { id: "prevention", name: "Prevention", icon: Shield, color: "bg-yellow-100" },
  ]

  const articles = [
    {
      id: 1,
      title: "Understanding High Blood Pressure",
      category: "heart",
      ageGroup: "elderly",
      readTime: "5 min",
      difficulty: "beginner",
      summary: "Learn about blood pressure, its causes, and how to manage it effectively.",
      content: "High blood pressure affects millions of people worldwide...",
      tags: ["blood pressure", "heart health", "prevention"],
    },
    {
      id: 2,
      title: "Healthy Eating on a Budget",
      category: "nutrition",
      ageGroup: "all",
      readTime: "7 min",
      difficulty: "beginner",
      summary: "Practical tips for maintaining a nutritious diet without breaking the bank.",
      content: "Eating healthy doesn't have to be expensive...",
      tags: ["nutrition", "budget", "meal planning"],
    },
    {
      id: 3,
      title: "Managing Stress and Anxiety",
      category: "mental",
      ageGroup: "youth",
      readTime: "6 min",
      difficulty: "beginner",
      summary: "Simple techniques to cope with daily stress and anxiety.",
      content: "Stress is a normal part of life, but chronic stress can impact your health...",
      tags: ["stress", "anxiety", "mental health", "coping"],
    },
    {
      id: 4,
      title: "Exercise for Seniors",
      category: "fitness",
      ageGroup: "elderly",
      readTime: "8 min",
      difficulty: "beginner",
      summary: "Safe and effective exercises for older adults to stay active.",
      content: "Regular physical activity is important at every age...",
      tags: ["exercise", "seniors", "safety", "mobility"],
    },
    {
      id: 5,
      title: "Diabetes Prevention",
      category: "prevention",
      ageGroup: "all",
      readTime: "10 min",
      difficulty: "intermediate",
      summary: "Understanding risk factors and lifestyle changes to prevent diabetes.",
      content: "Type 2 diabetes is largely preventable through lifestyle modifications...",
      tags: ["diabetes", "prevention", "lifestyle", "diet"],
    },
    {
      id: 6,
      title: "Teen Mental Health Awareness",
      category: "mental",
      ageGroup: "youth",
      readTime: "6 min",
      difficulty: "beginner",
      summary: "Recognizing signs of mental health issues in teenagers.",
      content: "Adolescence can be a challenging time with many changes...",
      tags: ["teens", "mental health", "awareness", "support"],
    },
    {
      id: 7,
      title: "Heart-Healthy Cooking",
      category: "nutrition",
      ageGroup: "all",
      readTime: "12 min",
      difficulty: "intermediate",
      summary: "Delicious recipes and cooking methods that support heart health.",
      content: "Cooking at home gives you control over ingredients and portions...",
      tags: ["cooking", "heart health", "recipes", "nutrition"],
    },
    {
      id: 8,
      title: "Building Healthy Habits",
      category: "prevention",
      ageGroup: "all",
      readTime: "9 min",
      difficulty: "beginner",
      summary: "Science-backed strategies for creating lasting healthy habits.",
      content: "Habits are the building blocks of a healthy lifestyle...",
      tags: ["habits", "behavior change", "wellness", "lifestyle"],
    },
  ]

  const filteredArticles = articles.filter((article) => {
    const matchesSearch =
      article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchTerm.toLowerCase()) ||
      article.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = selectedCategory === "all" || article.category === selectedCategory
    return matchesSearch && matchesCategory
  })

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "beginner":
        return "bg-green-100 text-green-800"
      case "intermediate":
        return "bg-yellow-100 text-yellow-800"
      case "advanced":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getAgeGroupIcon = (ageGroup: string) => {
    switch (ageGroup) {
      case "youth":
        return "👦"
      case "elderly":
        return "👴"
      case "all":
        return "👥"
      default:
        return "👥"
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-4">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Health Education</h1>
              <p className="text-gray-600">Learn about health topics that matter to you</p>
            </div>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="border-2">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search health topics..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 text-base"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Categories */}
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-xl">Browse by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
              {categories.map((category) => {
                const Icon = category.icon
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    className={`h-20 flex-col space-y-2 ${selectedCategory === category.id ? "" : category.color}`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <Icon className="w-6 h-6" />
                    <span className="text-xs">{category.name}</span>
                  </Button>
                )
              })}
            </div>
          </CardContent>
        </Card>

        {/* Featured Articles */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredArticles.map((article) => (
            <Card key={article.id} className="border-2 hover:shadow-lg transition-shadow cursor-pointer">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between mb-2">
                  <Badge variant="outline" className="text-xs">
                    {categories.find((c) => c.id === article.category)?.name}
                  </Badge>
                  <span className="text-lg">{getAgeGroupIcon(article.ageGroup)}</span>
                </div>
                <CardTitle className="text-lg leading-tight">{article.title}</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-sm text-gray-600 line-clamp-3">{article.summary}</p>

                <div className="flex items-center justify-between text-xs text-gray-500">
                  <div className="flex items-center space-x-3">
                    <span className="flex items-center">
                      <Clock className="w-3 h-3 mr-1" />
                      {article.readTime}
                    </span>
                    <Badge className={getDifficultyColor(article.difficulty)} variant="secondary">
                      {article.difficulty}
                    </Badge>
                  </div>
                </div>

                <div className="flex flex-wrap gap-1">
                  {article.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="outline" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>

                <Button className="w-full bg-transparent" variant="outline">
                  Read Article
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredArticles.length === 0 && (
          <Card className="border-2 border-dashed">
            <CardContent className="p-12 text-center">
              <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No articles found</h3>
              <p className="text-gray-500">Try adjusting your search terms or browse different categories</p>
            </CardContent>
          </Card>
        )}

        {/* Health Tips Section */}
        <Card className="border-2 bg-green-50">
          <CardHeader>
            <CardTitle className="text-xl text-green-900 flex items-center space-x-2">
              <Star className="w-5 h-5" />
              <span>Quick Health Tips</span>
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-green-800">
              <div className="space-y-3">
                <p className="flex items-start space-x-2">
                  <span className="text-green-600 mt-1">💧</span>
                  <span>Drink at least 8 glasses of water daily to stay hydrated</span>
                </p>
                <p className="flex items-start space-x-2">
                  <span className="text-green-600 mt-1">🚶</span>
                  <span>Take a 10-minute walk after meals to aid digestion</span>
                </p>
                <p className="flex items-start space-x-2">
                  <span className="text-green-600 mt-1">😴</span>
                  <span>Aim for 7-9 hours of quality sleep each night</span>
                </p>
              </div>
              <div className="space-y-3">
                <p className="flex items-start space-x-2">
                  <span className="text-green-600 mt-1">🥗</span>
                  <span>Fill half your plate with fruits and vegetables</span>
                </p>
                <p className="flex items-start space-x-2">
                  <span className="text-green-600 mt-1">🧘</span>
                  <span>Practice deep breathing for 5 minutes daily</span>
                </p>
                <p className="flex items-start space-x-2">
                  <span className="text-green-600 mt-1">🤝</span>
                  <span>Stay connected with friends and family for mental health</span>
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
