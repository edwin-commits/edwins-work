"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { ArrowLeft, Plus, Calendar, Clock, MapPin, Phone, Trash2, Bell } from "lucide-react"
import Link from "next/link"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

interface Appointment {
  id: number
  title: string
  doctor: string
  date: string
  time: string
  location: string
  phone?: string
  notes?: string
  type: string
  reminder: boolean
}

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([
    {
      id: 1,
      title: "Annual Physical Exam",
      doctor: "Dr. Sarah Johnson",
      date: "2024-01-25",
      time: "10:00",
      location: "123 Medical Plaza, Suite 200",
      phone: "(555) 123-4567",
      notes: "Bring insurance card and medication list",
      type: "checkup",
      reminder: true,
    },
    {
      id: 2,
      title: "Blood Pressure Follow-up",
      doctor: "Dr. Sarah Johnson",
      date: "2024-02-15",
      time: "14:30",
      location: "123 Medical Plaza, Suite 200",
      phone: "(555) 123-4567",
      notes: "Review medication effectiveness",
      type: "followup",
      reminder: true,
    },
  ])

  const [newAppointment, setNewAppointment] = useState<Partial<Appointment>>({
    title: "",
    doctor: "",
    date: "",
    time: "",
    location: "",
    phone: "",
    notes: "",
    type: "checkup",
    reminder: true,
  })

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  // Load appointments from localStorage
  useEffect(() => {
    const savedAppointments = localStorage.getItem("appointments")
    if (savedAppointments) {
      setAppointments(JSON.parse(savedAppointments))
    }
  }, [])

  // Save appointments to localStorage
  useEffect(() => {
    localStorage.setItem("appointments", JSON.stringify(appointments))
  }, [appointments])

  const appointmentTypes = [
    { id: "checkup", name: "Check-up", icon: "🏥", color: "bg-blue-100 text-blue-800" },
    { id: "followup", name: "Follow-up", icon: "🔄", color: "bg-green-100 text-green-800" },
    { id: "specialist", name: "Specialist", icon: "👨‍⚕️", color: "bg-purple-100 text-purple-800" },
    { id: "dental", name: "Dental", icon: "🦷", color: "bg-yellow-100 text-yellow-800" },
    { id: "vision", name: "Vision", icon: "👁️", color: "bg-pink-100 text-pink-800" },
    { id: "therapy", name: "Therapy", icon: "🧠", color: "bg-indigo-100 text-indigo-800" },
  ]

  const addAppointment = () => {
    if (newAppointment.title && newAppointment.date && newAppointment.time) {
      const appointment: Appointment = {
        id: Date.now(),
        title: newAppointment.title,
        doctor: newAppointment.doctor || "",
        date: newAppointment.date,
        time: newAppointment.time,
        location: newAppointment.location || "",
        phone: newAppointment.phone || "",
        notes: newAppointment.notes || "",
        type: newAppointment.type || "checkup",
        reminder: newAppointment.reminder || true,
      }
      setAppointments([...appointments, appointment])
      setNewAppointment({
        title: "",
        doctor: "",
        date: "",
        time: "",
        location: "",
        phone: "",
        notes: "",
        type: "checkup",
        reminder: true,
      })
      setIsAddDialogOpen(false)
    }
  }

  const deleteAppointment = (id: number) => {
    setAppointments(appointments.filter((apt) => apt.id !== id))
  }

  const getTypeInfo = (typeId: string) => {
    return appointmentTypes.find((type) => type.id === typeId) || appointmentTypes[0]
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", {
      weekday: "long",
      year: "numeric",
      month: "long",
      day: "numeric",
    })
  }

  const formatTime = (timeString: string) => {
    const [hours, minutes] = timeString.split(":")
    const date = new Date()
    date.setHours(Number.parseInt(hours), Number.parseInt(minutes))
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
    })
  }

  const isUpcoming = (dateString: string, timeString: string) => {
    const appointmentDate = new Date(`${dateString}T${timeString}`)
    return appointmentDate > new Date()
  }

  const upcomingAppointments = appointments
    .filter((apt) => isUpcoming(apt.date, apt.time))
    .sort((a, b) => new Date(`${a.date}T${a.time}`).getTime() - new Date(`${b.date}T${b.time}`).getTime())

  const pastAppointments = appointments
    .filter((apt) => !isUpcoming(apt.date, apt.time))
    .sort((a, b) => new Date(`${b.date}T${b.time}`).getTime() - new Date(`${a.date}T${a.time}`).getTime())

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 p-4">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <Link href="/">
              <Button variant="outline" size="icon">
                <ArrowLeft className="w-4 h-4" />
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold text-gray-900">Appointments</h1>
              <p className="text-gray-600">Manage your medical appointments</p>
            </div>
          </div>
          <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
            <DialogTrigger asChild>
              <Button size="lg">
                <Plus className="w-5 h-5 mr-2" />
                Add Appointment
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-md">
              <DialogHeader>
                <DialogTitle className="text-xl">Schedule Appointment</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="apt-title" className="text-base">
                    Appointment Title *
                  </Label>
                  <Input
                    id="apt-title"
                    placeholder="e.g., Annual Physical Exam"
                    value={newAppointment.title || ""}
                    onChange={(e) => setNewAppointment({ ...newAppointment, title: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="apt-doctor" className="text-base">
                    Doctor/Provider
                  </Label>
                  <Input
                    id="apt-doctor"
                    placeholder="e.g., Dr. Smith"
                    value={newAppointment.doctor || ""}
                    onChange={(e) => setNewAppointment({ ...newAppointment, doctor: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="apt-date" className="text-base">
                      Date *
                    </Label>
                    <Input
                      id="apt-date"
                      type="date"
                      value={newAppointment.date || ""}
                      onChange={(e) => setNewAppointment({ ...newAppointment, date: e.target.value })}
                      className="text-base"
                    />
                  </div>
                  <div>
                    <Label htmlFor="apt-time" className="text-base">
                      Time *
                    </Label>
                    <Input
                      id="apt-time"
                      type="time"
                      value={newAppointment.time || ""}
                      onChange={(e) => setNewAppointment({ ...newAppointment, time: e.target.value })}
                      className="text-base"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="apt-type" className="text-base">
                    Type
                  </Label>
                  <Select
                    value={newAppointment.type}
                    onValueChange={(value) => setNewAppointment({ ...newAppointment, type: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {appointmentTypes.map((type) => (
                        <SelectItem key={type.id} value={type.id}>
                          {type.icon} {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="apt-location" className="text-base">
                    Location
                  </Label>
                  <Input
                    id="apt-location"
                    placeholder="Address or clinic name"
                    value={newAppointment.location || ""}
                    onChange={(e) => setNewAppointment({ ...newAppointment, location: e.target.value })}
                    className="text-base"
                  />
                </div>
                <div>
                  <Label htmlFor="apt-notes" className="text-base">
                    Notes
                  </Label>
                  <Textarea
                    id="apt-notes"
                    placeholder="Preparation notes, questions to ask..."
                    value={newAppointment.notes || ""}
                    onChange={(e) => setNewAppointment({ ...newAppointment, notes: e.target.value })}
                    className="text-base"
                    rows={2}
                  />
                </div>
                <Button onClick={addAppointment} className="w-full text-base" size="lg">
                  Schedule Appointment
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Upcoming Appointments */}
        {upcomingAppointments.length > 0 && (
          <Card className="border-2 border-green-200 bg-green-50">
            <CardHeader>
              <CardTitle className="text-xl text-green-900 flex items-center space-x-2">
                <Calendar className="w-5 h-5" />
                <span>Upcoming Appointments</span>
                <Badge variant="outline">{upcomingAppointments.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingAppointments.map((appointment) => (
                  <div key={appointment.id} className="bg-white p-4 rounded-lg border border-green-200">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-semibold text-lg">{appointment.title}</h3>
                          <Badge className={getTypeInfo(appointment.type).color}>
                            {getTypeInfo(appointment.type).icon}
                          </Badge>
                          {appointment.reminder && <Bell className="w-4 h-4 text-blue-500" />}
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{appointment.doctor}</p>
                        <div className="space-y-1 text-sm text-gray-600">
                          <p className="flex items-center">
                            <Calendar className="w-4 h-4 mr-2" />
                            {formatDate(appointment.date)}
                          </p>
                          <p className="flex items-center">
                            <Clock className="w-4 h-4 mr-2" />
                            {formatTime(appointment.time)}
                          </p>
                          {appointment.location && (
                            <p className="flex items-center">
                              <MapPin className="w-4 h-4 mr-2" />
                              {appointment.location}
                            </p>
                          )}
                          {appointment.phone && (
                            <p className="flex items-center">
                              <Phone className="w-4 h-4 mr-2" />
                              {appointment.phone}
                            </p>
                          )}
                        </div>
                        {appointment.notes && (
                          <p className="text-sm text-gray-700 mt-2 bg-gray-50 p-2 rounded border">
                            {appointment.notes}
                          </p>
                        )}
                      </div>
                      <div className="flex items-center space-x-2">
                        {appointment.phone && (
                          <Button
                            onClick={() => (window.location.href = `tel:${appointment.phone}`)}
                            size="sm"
                            variant="outline"
                          >
                            <Phone className="w-4 h-4" />
                          </Button>
                        )}
                        <Button onClick={() => deleteAppointment(appointment.id)} variant="outline" size="sm">
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Past Appointments */}
        {pastAppointments.length > 0 && (
          <Card className="border-2">
            <CardHeader>
              <CardTitle className="text-xl flex items-center space-x-2">
                <Clock className="w-5 h-5" />
                <span>Past Appointments</span>
                <Badge variant="outline">{pastAppointments.length}</Badge>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {pastAppointments.slice(0, 5).map((appointment) => (
                  <div key={appointment.id} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-1">
                          <h3 className="font-medium text-gray-700">{appointment.title}</h3>
                          <Badge variant="outline" className="text-xs">
                            {getTypeInfo(appointment.type).name}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-1">{appointment.doctor}</p>
                        <p className="text-xs text-gray-500">
                          {formatDate(appointment.date)} at {formatTime(appointment.time)}
                        </p>
                      </div>
                      <Button onClick={() => deleteAppointment(appointment.id)} variant="ghost" size="sm">
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {appointments.length === 0 && (
          <Card className="border-2 border-dashed">
            <CardContent className="p-12 text-center">
              <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-600 mb-2">No appointments scheduled</h3>
              <p className="text-gray-500 mb-6">
                Keep track of your medical appointments and never miss an important visit
              </p>
              <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="lg">
                    <Plus className="w-5 h-5 mr-2" />
                    Schedule Your First Appointment
                  </Button>
                </DialogTrigger>
                <DialogContent className="sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="text-xl">Schedule Appointment</DialogTitle>
                  </DialogHeader>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="apt-title" className="text-base">
                        Appointment Title *
                      </Label>
                      <Input
                        id="apt-title"
                        placeholder="e.g., Annual Physical Exam"
                        value={newAppointment.title || ""}
                        onChange={(e) => setNewAppointment({ ...newAppointment, title: e.target.value })}
                        className="text-base"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="apt-date" className="text-base">
                          Date *
                        </Label>
                        <Input
                          id="apt-date"
                          type="date"
                          value={newAppointment.date || ""}
                          onChange={(e) => setNewAppointment({ ...newAppointment, date: e.target.value })}
                          className="text-base"
                        />
                      </div>
                      <div>
                        <Label htmlFor="apt-time" className="text-base">
                          Time *
                        </Label>
                        <Input
                          id="apt-time"
                          type="time"
                          value={newAppointment.time || ""}
                          onChange={(e) => setNewAppointment({ ...newAppointment, time: e.target.value })}
                          className="text-base"
                        />
                      </div>
                    </div>
                    <Button onClick={addAppointment} className="w-full text-base" size="lg">
                      Schedule Appointment
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        )}

        {/* Appointment Tips */}
        <Card className="border-2 bg-blue-50">
          <CardHeader>
            <CardTitle className="text-xl text-blue-900">💡 Appointment Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 text-blue-800">
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Arrive 15 minutes early for check-in and paperwork</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Bring your insurance card, ID, and current medication list</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Write down questions beforehand so you don't forget to ask</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Confirm appointments 24 hours in advance</span>
              </p>
              <p className="flex items-start space-x-2">
                <span className="text-blue-600 mt-1">•</span>
                <span>Keep a record of all appointments and follow-up instructions</span>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
